
rq is a simple, lightweight, library for creating background jobs, and
processing them.


